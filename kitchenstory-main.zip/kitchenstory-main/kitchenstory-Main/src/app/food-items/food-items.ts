export interface efood
{
    Item:number,
    Name:string,
    Cost:number,
    Rating:number,
    qnt:number,
    Img:string
}